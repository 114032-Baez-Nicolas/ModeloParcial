﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
//114032 - Báez Nicolás

namespace Ejercicio__ModeloParcial_.Datos
{
    public class HelperDAO
    {
        SqlConnection lConexion = new SqlConnection(Properties.Resources.CadenaConexion);
        SqlCommand lComando = new SqlCommand();
        private static HelperDAO lInstancia;

        private HelperDAO()
        {
        }

        public static HelperDAO ObtenerInstancia()
        {
            if(lInstancia == null)
            {
                lInstancia = new HelperDAO();
            }

            return lInstancia;
        }

        private void ConectarSP()
        {
            lConexion.Open();
            lComando.Connection = lConexion;
            lComando.CommandType = CommandType.StoredProcedure;
        }

        private void Desconectar()
        {
            lConexion.Close();
        }

        public DataTable ComboBox(string SPSQL)
        {
            DataTable lTabla = new DataTable();
            ConectarSP();
            lComando.CommandText = SPSQL;

            lTabla.Load(lComando.ExecuteReader());
            Desconectar();

            return lTabla;
        }

        public DataTable FormConsultar(string SPSQL, List<Parametro> lstParametros)
        {
            DataTable lTabla = new DataTable();
            ConectarSP();
            lComando.CommandText= SPSQL;
            lComando.Parameters.Clear();

            foreach(Parametro lParam in lstParametros)
            {
                lComando.Parameters.AddWithValue(lParam.Nombre, lParam.Valor);
            }

            lTabla.Load(lComando.ExecuteReader());
            Desconectar();

            return lTabla;
        }

        public SqlConnection ObtenerConexion()
        {
            return lConexion;
        }
    }
}
