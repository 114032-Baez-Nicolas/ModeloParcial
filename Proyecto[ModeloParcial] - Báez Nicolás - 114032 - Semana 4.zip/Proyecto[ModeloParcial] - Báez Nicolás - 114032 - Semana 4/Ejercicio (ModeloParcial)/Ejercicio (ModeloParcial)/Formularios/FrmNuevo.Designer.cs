﻿namespace Ejercicio__ModeloParcial_.Formularios
{
    partial class FrmNuevo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GpDatos = new System.Windows.Forms.GroupBox();
            this.TxtCantidad = new System.Windows.Forms.TextBox();
            this.LblMateriales = new System.Windows.Forms.Label();
            this.LblCantidad = new System.Windows.Forms.Label();
            this.DtFecha = new System.Windows.Forms.DateTimePicker();
            this.CboMaterial = new System.Windows.Forms.ComboBox();
            this.LblFecha = new System.Windows.Forms.Label();
            this.LblResponsable = new System.Windows.Forms.Label();
            this.TxtResponsable = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.BtnAceptar = new System.Windows.Forms.Button();
            this.BtnAgregar = new System.Windows.Forms.Button();
            this.DgvDetalles = new System.Windows.Forms.DataGridView();
            this.ColMaterial = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColStock = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColCantidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColAcciones = new System.Windows.Forms.DataGridViewButtonColumn();
            this.LblNuevaOrden = new System.Windows.Forms.Label();
            this.GbControl = new System.Windows.Forms.GroupBox();
            this.GpDatos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvDetalles)).BeginInit();
            this.GbControl.SuspendLayout();
            this.SuspendLayout();
            // 
            // GpDatos
            // 
            this.GpDatos.Controls.Add(this.TxtCantidad);
            this.GpDatos.Controls.Add(this.LblMateriales);
            this.GpDatos.Controls.Add(this.LblCantidad);
            this.GpDatos.Controls.Add(this.DtFecha);
            this.GpDatos.Controls.Add(this.CboMaterial);
            this.GpDatos.Controls.Add(this.LblFecha);
            this.GpDatos.Controls.Add(this.LblResponsable);
            this.GpDatos.Controls.Add(this.TxtResponsable);
            this.GpDatos.Location = new System.Drawing.Point(19, 69);
            this.GpDatos.Name = "GpDatos";
            this.GpDatos.Size = new System.Drawing.Size(446, 194);
            this.GpDatos.TabIndex = 0;
            this.GpDatos.TabStop = false;
            this.GpDatos.Text = "Datos";
            // 
            // TxtCantidad
            // 
            this.TxtCantidad.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtCantidad.Location = new System.Drawing.Point(128, 136);
            this.TxtCantidad.Name = "TxtCantidad";
            this.TxtCantidad.Size = new System.Drawing.Size(89, 24);
            this.TxtCantidad.TabIndex = 5;
            // 
            // LblMateriales
            // 
            this.LblMateriales.AutoSize = true;
            this.LblMateriales.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblMateriales.Location = new System.Drawing.Point(6, 105);
            this.LblMateriales.Name = "LblMateriales";
            this.LblMateriales.Size = new System.Drawing.Size(104, 21);
            this.LblMateriales.TabIndex = 30;
            this.LblMateriales.Text = "Tipo Material:";
            // 
            // LblCantidad
            // 
            this.LblCantidad.AutoSize = true;
            this.LblCantidad.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblCantidad.Location = new System.Drawing.Point(21, 141);
            this.LblCantidad.Name = "LblCantidad";
            this.LblCantidad.Size = new System.Drawing.Size(75, 21);
            this.LblCantidad.TabIndex = 29;
            this.LblCantidad.Text = "Cantidad:";
            // 
            // DtFecha
            // 
            this.DtFecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DtFecha.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DtFecha.Location = new System.Drawing.Point(128, 33);
            this.DtFecha.Name = "DtFecha";
            this.DtFecha.Size = new System.Drawing.Size(112, 22);
            this.DtFecha.TabIndex = 1;
            // 
            // CboMaterial
            // 
            this.CboMaterial.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CboMaterial.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CboMaterial.FormattingEnabled = true;
            this.CboMaterial.Location = new System.Drawing.Point(128, 101);
            this.CboMaterial.Name = "CboMaterial";
            this.CboMaterial.Size = new System.Drawing.Size(282, 24);
            this.CboMaterial.TabIndex = 4;
            // 
            // LblFecha
            // 
            this.LblFecha.AutoSize = true;
            this.LblFecha.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblFecha.Location = new System.Drawing.Point(32, 33);
            this.LblFecha.Name = "LblFecha";
            this.LblFecha.Size = new System.Drawing.Size(53, 21);
            this.LblFecha.TabIndex = 32;
            this.LblFecha.Text = "Fecha:";
            // 
            // LblResponsable
            // 
            this.LblResponsable.AutoSize = true;
            this.LblResponsable.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblResponsable.Location = new System.Drawing.Point(8, 69);
            this.LblResponsable.Name = "LblResponsable";
            this.LblResponsable.Size = new System.Drawing.Size(101, 21);
            this.LblResponsable.TabIndex = 30;
            this.LblResponsable.Text = "Responsable:";
            // 
            // TxtResponsable
            // 
            this.TxtResponsable.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtResponsable.Location = new System.Drawing.Point(128, 66);
            this.TxtResponsable.Name = "TxtResponsable";
            this.TxtResponsable.Size = new System.Drawing.Size(282, 24);
            this.TxtResponsable.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(618, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 35;
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.Location = new System.Drawing.Point(201, 56);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(75, 23);
            this.BtnCancelar.TabIndex = 2;
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.UseVisualStyleBackColor = true;
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click);
            // 
            // BtnAceptar
            // 
            this.BtnAceptar.Location = new System.Drawing.Point(110, 56);
            this.BtnAceptar.Name = "BtnAceptar";
            this.BtnAceptar.Size = new System.Drawing.Size(75, 23);
            this.BtnAceptar.TabIndex = 1;
            this.BtnAceptar.Text = "Aceptar";
            this.BtnAceptar.UseVisualStyleBackColor = true;
            this.BtnAceptar.Click += new System.EventHandler(this.BtnAceptar_Click);
            // 
            // BtnAgregar
            // 
            this.BtnAgregar.Location = new System.Drawing.Point(18, 56);
            this.BtnAgregar.Name = "BtnAgregar";
            this.BtnAgregar.Size = new System.Drawing.Size(75, 23);
            this.BtnAgregar.TabIndex = 0;
            this.BtnAgregar.Text = "Agregar";
            this.BtnAgregar.UseVisualStyleBackColor = true;
            this.BtnAgregar.Click += new System.EventHandler(this.BtnAgregar_Click);
            // 
            // DgvDetalles
            // 
            this.DgvDetalles.AllowUserToAddRows = false;
            this.DgvDetalles.AllowUserToDeleteRows = false;
            this.DgvDetalles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvDetalles.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColMaterial,
            this.ColStock,
            this.ColCantidad,
            this.ColAcciones});
            this.DgvDetalles.Location = new System.Drawing.Point(54, 289);
            this.DgvDetalles.Name = "DgvDetalles";
            this.DgvDetalles.ReadOnly = true;
            this.DgvDetalles.Size = new System.Drawing.Size(729, 206);
            this.DgvDetalles.TabIndex = 2;
            this.DgvDetalles.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvDetalles_CellContentClick);
            // 
            // ColMaterial
            // 
            this.ColMaterial.HeaderText = "Material";
            this.ColMaterial.Name = "ColMaterial";
            this.ColMaterial.ReadOnly = true;
            this.ColMaterial.Width = 250;
            // 
            // ColStock
            // 
            this.ColStock.HeaderText = "Stock";
            this.ColStock.Name = "ColStock";
            this.ColStock.ReadOnly = true;
            this.ColStock.Width = 110;
            // 
            // ColCantidad
            // 
            this.ColCantidad.HeaderText = "Cantidad";
            this.ColCantidad.Name = "ColCantidad";
            this.ColCantidad.ReadOnly = true;
            this.ColCantidad.Width = 225;
            // 
            // ColAcciones
            // 
            this.ColAcciones.HeaderText = "Acciones";
            this.ColAcciones.Name = "ColAcciones";
            this.ColAcciones.ReadOnly = true;
            this.ColAcciones.Text = "Quitar";
            this.ColAcciones.UseColumnTextForButtonValue = true;
            // 
            // LblNuevaOrden
            // 
            this.LblNuevaOrden.AutoSize = true;
            this.LblNuevaOrden.Font = new System.Drawing.Font("Microsoft Tai Le", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblNuevaOrden.ForeColor = System.Drawing.Color.Coral;
            this.LblNuevaOrden.Location = new System.Drawing.Point(12, 9);
            this.LblNuevaOrden.Name = "LblNuevaOrden";
            this.LblNuevaOrden.Size = new System.Drawing.Size(299, 40);
            this.LblNuevaOrden.TabIndex = 34;
            this.LblNuevaOrden.Text = "Nueva Orden Retiro";
            // 
            // GbControl
            // 
            this.GbControl.Controls.Add(this.BtnCancelar);
            this.GbControl.Controls.Add(this.BtnAceptar);
            this.GbControl.Controls.Add(this.BtnAgregar);
            this.GbControl.Location = new System.Drawing.Point(492, 100);
            this.GbControl.Name = "GbControl";
            this.GbControl.Size = new System.Drawing.Size(291, 129);
            this.GbControl.TabIndex = 1;
            this.GbControl.TabStop = false;
            this.GbControl.Text = "Control";
            // 
            // FrmNuevo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(852, 517);
            this.Controls.Add(this.GbControl);
            this.Controls.Add(this.GpDatos);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.DgvDetalles);
            this.Controls.Add(this.LblNuevaOrden);
            this.Name = "FrmNuevo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Nuevo";
            this.Load += new System.EventHandler(this.FrmNuevo_Load);
            this.GpDatos.ResumeLayout(false);
            this.GpDatos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvDetalles)).EndInit();
            this.GbControl.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox GpDatos;
        private System.Windows.Forms.DateTimePicker DtFecha;
        private System.Windows.Forms.Label LblFecha;
        private System.Windows.Forms.Label LblResponsable;
        private System.Windows.Forms.TextBox TxtResponsable;
        private System.Windows.Forms.Label LblMateriales;
        private System.Windows.Forms.TextBox TxtCantidad;
        private System.Windows.Forms.Label LblCantidad;
        private System.Windows.Forms.ComboBox CboMaterial;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button BtnCancelar;
        private System.Windows.Forms.Button BtnAceptar;
        private System.Windows.Forms.Button BtnAgregar;
        private System.Windows.Forms.DataGridView DgvDetalles;
        private System.Windows.Forms.Label LblNuevaOrden;
        private System.Windows.Forms.GroupBox GbControl;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColMaterial;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColStock;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColCantidad;
        private System.Windows.Forms.DataGridViewButtonColumn ColAcciones;
    }
}