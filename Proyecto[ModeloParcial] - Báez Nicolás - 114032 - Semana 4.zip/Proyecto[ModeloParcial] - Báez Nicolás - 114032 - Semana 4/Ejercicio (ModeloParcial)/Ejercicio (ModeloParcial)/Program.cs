﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Ejercicio__ModeloParcial_.Formularios;
using Ejercicio__ModeloParcial_.Servicios.Implementaciones;
//114032 - Báez Nicolás

namespace Ejercicio__ModeloParcial_
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FrmPrincipal(new FabricaServicios()));
        }
    }
}
