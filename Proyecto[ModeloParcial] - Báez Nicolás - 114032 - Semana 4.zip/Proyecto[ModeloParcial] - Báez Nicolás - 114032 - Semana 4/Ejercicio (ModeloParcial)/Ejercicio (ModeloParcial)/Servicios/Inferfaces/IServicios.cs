﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio__ModeloParcial_.Datos.Implementaciones;
using Ejercicio__ModeloParcial_.Datos.Interfaces;
using Ejercicio__ModeloParcial_.Datos;
using SimulacroParcial1.Entidades;
//114032 Báez Nicolás

namespace Ejercicio__ModeloParcial_.Servicios.Inferfaces
{
    public interface IServicios
    {
        List<Material> TraerComboMateriales();
        bool TraerMaestroDetalle(OrdenRetiro oOrdenRetiro);
        bool TraerStock(int lCantidad, Material lMaterial);
        int TraerNroOrdenRetiro();
    }
}
