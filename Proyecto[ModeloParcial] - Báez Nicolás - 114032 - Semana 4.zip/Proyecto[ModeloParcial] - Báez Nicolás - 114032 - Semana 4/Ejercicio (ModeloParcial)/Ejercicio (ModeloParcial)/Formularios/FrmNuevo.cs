﻿using Ejercicio__ModeloParcial_.Servicios.Inferfaces;
using SimulacroParcial1.Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//114032 - Báez Nicolás

namespace Ejercicio__ModeloParcial_.Formularios
{
    public partial class FrmNuevo : Form
    {
        IServicios oServicio;
        OrdenRetiro oNuevaOrdenRetiro;

        public FrmNuevo(IFabricaServicios lFabrica)
        {
            InitializeComponent();
            oNuevaOrdenRetiro = new OrdenRetiro();

            oServicio = lFabrica.CrearServicio();
        }

        private void FrmNuevo_Load(object sender, EventArgs e)
        {
            DtFecha.Value = DateTime.Now;
            TxtResponsable.Text = "LEO MESSI";
            TxtCantidad.Text = "1";

            CargarCombo();
        }

        private void CargarCombo()
        {
            CboMaterial.DataSource = oServicio.TraerComboMateriales();
            CboMaterial.ValueMember = "codigo";
            CboMaterial.DisplayMember = "nombre";

            CboMaterial.SelectedIndex = -1;
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private bool ValidarAgregar()
        {
            bool resultado = true;

            if (string.IsNullOrEmpty(TxtResponsable.Text))
            {
                MessageBox.Show("Error, debe ingresar un responsable..", "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                TxtResponsable.Focus();
                resultado = false;
            }
            else if (string.Empty.Equals(CboMaterial.Text)) 
            {
                MessageBox.Show("Error, debe ingresar un tipo de material..", "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                CboMaterial.Focus();
                resultado = false;
            }
            else if (string.IsNullOrEmpty(TxtCantidad.Text))
            {
                MessageBox.Show("Error, debe ingresar una cantidad..", "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                TxtCantidad.Focus();
                resultado = false;
            }
            else if (!oServicio.TraerStock(Convert.ToInt32(TxtCantidad.Text),
                (Material)CboMaterial.SelectedItem))
            {
                MessageBox.Show("Error, no hay stock suficiente..", "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                TxtCantidad.Focus();
                resultado = false;
            }

            foreach (DataGridViewRow lItem in DgvDetalles.Rows)
            {
                if (lItem.Cells["ColMaterial"].Value.ToString().Equals(CboMaterial.Text))
                {
                    MessageBox.Show("Error, ese material ya se encuentra presupuestado..", "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                    CboMaterial.Focus();
                    resultado = false;
                }
            }

            return resultado;
        }

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            if (ValidarAgregar() is true)
            {
                Material oMaterial = (Material)CboMaterial.SelectedItem;
                int lCantidad = Convert.ToInt32(TxtCantidad.Text);
                DetalleOrden oDetalleOrden = new DetalleOrden(oMaterial, lCantidad);

                oNuevaOrdenRetiro.AgregarDetalle(oDetalleOrden);
                DgvDetalles.Rows.Add(new object[] {oMaterial.nombre, oMaterial.stock, lCantidad });

            }
        }

        private bool ValidarAceptar()
        {
            bool resultado = true;

            if(DgvDetalles.Rows.Count == 0)
            {
                MessageBox.Show("Error, debe ingresar al menos un material..", "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                resultado = false;
            }

            return resultado;
        }

        private void DgvDetalles_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (DgvDetalles.CurrentCell.ColumnIndex == 3)
            {
                oNuevaOrdenRetiro.QuitarDetalle(DgvDetalles.CurrentRow.Index);
                DgvDetalles.Rows.Remove(DgvDetalles.CurrentRow);
            }
        }

        private void BtnAceptar_Click(object sender, EventArgs e)
        {
            if (ValidarAceptar() is true) 
            {
                oNuevaOrdenRetiro.fecha = Convert.ToDateTime(DtFecha.Text);
                oNuevaOrdenRetiro.responsable = TxtResponsable.Text;

                if (oServicio.TraerMaestroDetalle(oNuevaOrdenRetiro) is true)
                {
                    MessageBox.Show("Se cargó con éxito la orden nro " + oServicio.TraerNroOrdenRetiro() + "!",
                       "INFO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Dispose();
                }
                else
                {
                    MessageBox.Show("Ocurrio un error en la carga..", "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                }

            }
        }
    }
}
