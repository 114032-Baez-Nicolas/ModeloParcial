﻿using Ejercicio__ModeloParcial_.Datos;
using Ejercicio__ModeloParcial_.Datos.Implementaciones;
using Ejercicio__ModeloParcial_.Datos.Interfaces;
using Ejercicio__ModeloParcial_.Servicios.Inferfaces;
using SimulacroParcial1.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//114032 Báez Nicolás

namespace Ejercicio__ModeloParcial_.Servicios.Implementaciones
{
    public class Servicios : IServicios
    {
        private IOrdenDAO dao;

        public Servicios()
        {
            dao = new OrdenDAO();
        }

        public List<Material> TraerComboMateriales()
        {
            return dao.ObtenerComboMateriales();
        }

        public bool TraerMaestroDetalle(OrdenRetiro oOrdenRetiro)
        {
            return dao.CrearMaestroDetalle(oOrdenRetiro);
        }

        public bool TraerStock(int lCantidad, Material lMaterial)
        {
            return dao.ObtenerStock(lCantidad, lMaterial);
        }

        public int TraerNroOrdenRetiro()
        {
            return dao.NroOrdenRetiro();
        }

    }
}
