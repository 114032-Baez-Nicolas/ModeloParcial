﻿using SimulacroParcial1.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//114032 - Báez Nicolás

namespace Ejercicio__ModeloParcial_.Datos.Interfaces
{
    public interface IOrdenDAO
    {
        List<Material> ObtenerComboMateriales();
        bool CrearMaestroDetalle(OrdenRetiro oOrdenRetiro);
        bool ObtenerStock(int lCantidad, Material lMaterial);
        int NroOrdenRetiro();

    }
}
