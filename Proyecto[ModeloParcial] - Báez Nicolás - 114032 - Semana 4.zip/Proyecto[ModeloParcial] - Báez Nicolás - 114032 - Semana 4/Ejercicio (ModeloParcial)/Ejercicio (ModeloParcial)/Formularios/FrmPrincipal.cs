﻿using Ejercicio__ModeloParcial_.Servicios.Inferfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//114032 - Báez Nicolás

namespace Ejercicio__ModeloParcial_.Formularios
{
    public partial class FrmPrincipal : Form
    {
        private IFabricaServicios lFabrica;

        public FrmPrincipal(IFabricaServicios fabrica)
        {
            InitializeComponent();
            this.lFabrica = fabrica;
        }

        private void nuevoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmNuevo lNuevo = new FrmNuevo(lFabrica);
            lNuevo.ShowDialog();
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {

        }
    }
}
