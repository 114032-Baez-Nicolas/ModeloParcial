﻿using Ejercicio__ModeloParcial_.Datos.Interfaces;
using SimulacroParcial1.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//114032 - Báez Nicolás

namespace Ejercicio__ModeloParcial_.Datos.Implementaciones
{
    public class OrdenDAO : IOrdenDAO
    {
        SqlConnection lConexion = HelperDAO.ObtenerInstancia().ObtenerConexion();
        SqlCommand lComando = new SqlCommand();

        SqlTransaction lTransaction = null;
        int nroOrden = 0;   

        public List<Material> ObtenerComboMateriales()
        {
            List<Material> lstMateriales = new List<Material>();
            DataTable lTabla = HelperDAO.ObtenerInstancia().ComboBox("SP_CONSULTAR_MATERIALES");

            foreach (DataRow lFila in  lTabla.Rows)
            {
                int lCodigo = Convert.ToInt32(lFila["codigo"]);
                string lNombre = lFila["nombre"].ToString();
                int lStock = Convert.ToInt32(lFila["stock"]);

                Material oMaterial = new Material(lCodigo, lNombre, lStock);
                lstMateriales.Add(oMaterial);
            }

            return lstMateriales;
        }

        private void CommandTransaction()
        {
            lConexion.Open();
            lComando.Connection = lConexion;
            lComando.CommandType = CommandType.StoredProcedure;

            lTransaction = lConexion.BeginTransaction();
            lComando.Transaction = lTransaction;
            lComando.CommandText = "SP_INSERTAR_ORDEN";
        }

        public bool CrearMaestroDetalle(OrdenRetiro oOrdenRetiro)
        {
            bool resultado;

            try
            {
                CommandTransaction();
                lComando.Parameters.AddWithValue("@responsable", oOrdenRetiro.responsable);
                SqlParameter lParametro = new SqlParameter("@nro", SqlDbType.Int);
                lParametro.Direction = ParameterDirection.Output;

                lComando.Parameters.Add(lParametro);
                lComando.ExecuteNonQuery();

                nroOrden = (int)lParametro.Value;
                int lDetalleNro = 0;

                SqlCommand cmdDetalle;

                foreach (DetalleOrden lDetalle in oOrdenRetiro.detalleOrden)
                {
                    cmdDetalle = new SqlCommand("SP_INSERTAR_DETALLES", lConexion, lTransaction);
                    cmdDetalle.CommandType = CommandType.StoredProcedure;

                    cmdDetalle.Parameters.AddWithValue("@nro_orden", nroOrden);
                    cmdDetalle.Parameters.AddWithValue("@detalle", ++lDetalleNro);
                    cmdDetalle.Parameters.AddWithValue("@codigo", lDetalle.material.codigo);
                    cmdDetalle.Parameters.AddWithValue("@cantidad", lDetalle.cantidad);

                    cmdDetalle.ExecuteNonQuery();
                }
                lTransaction.Commit();
                resultado = true;
            }
            catch
            {
                lTransaction.Rollback();
                resultado = false;
            }
            finally
            {
                if (lConexion != null && lConexion.State == ConnectionState.Open) 
                {
                    lConexion.Close();
                }
            }

            return resultado;
        }

        public bool ObtenerStock(int lCantidad, Material lMaterial)
        {
            bool resultado;

            if(lCantidad <= lMaterial.stock)
            {
                resultado = true;
            }
            else
            {
                resultado = false;
            }

            return resultado;
        }

        public int NroOrdenRetiro()
        {
            return nroOrden;
        }
    }
}
