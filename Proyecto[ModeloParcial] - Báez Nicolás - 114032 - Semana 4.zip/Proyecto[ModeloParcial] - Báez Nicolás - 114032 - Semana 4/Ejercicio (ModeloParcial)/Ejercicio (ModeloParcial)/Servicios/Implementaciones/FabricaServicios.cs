﻿using Ejercicio__ModeloParcial_.Servicios.Inferfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//114032 Báez Nicolás

namespace Ejercicio__ModeloParcial_.Servicios.Implementaciones
{
    public class FabricaServicios : IFabricaServicios
    {
        public IServicios CrearServicio()
        {
            return new Servicios();
        }
    }
}
